// URL del backend. Déjalo vacío ('') si el backend también sirve el frontend (mismo servidor y puerto).
// Si despliegas el frontend aparte, pon la URL del backend, ej.: 'http://TU_IP_SERVIDOR:3000'
window.MONEYU_API = '';
