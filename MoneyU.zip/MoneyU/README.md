# MoneyU - Control de Gastos Estudiantil

```
MoneyU/
├── frontend/   index.html + config.js   (interfaz)
├── backend/    server.js + data/db.json (API y base de datos en el SERVIDOR)
└── README.md
```

Los datos viven en `backend/data/db.json` del servidor. El navegador no guarda gastos (solo la preferencia de modo oscuro).

## 1. Probar local
```bash
cd backend && node server.js      # abre http://localhost:3000
```

## 2. Subir a GitHub (rama principal, 10%)
```bash
git add MoneyU && git commit -m "Agrega MoneyU: frontend y backend"
git push origin main
```

## 3. Despliegue por SSH con llave privada (10% frontend + 10% backend)
```bash
ssh -i ~/.ssh/TU_LLAVE usuario@IP_SERVIDOR          # probar acceso
git clone git@github.com:USUARIO/REPO.git            # primera vez
cd REPO/MoneyU/backend && npm start                  # o: nohup node server.js &
```
Para actualizar: `git pull origin main` en el servidor y reiniciar. Abre el puerto 3000 en el firewall del servidor.
Si el frontend va aparte, edita `frontend/config.js` con la URL del backend.

## 4. Merge (20%)
```bash
git checkout -b feature/moneyu
# ...haces un cambio visible (ej. color o texto)...
git add . && git commit -m "Cambio visible"
git checkout main && git merge feature/moneyu && git push origin main
```

## 5. Sensores (10%)
Esta app web no usa sensores. Muestra en tu proyecto KMP los archivos de sensores
(`AndroidManifest.xml` con permisos y el archivo en `androidMain` que usa SensorManager).
