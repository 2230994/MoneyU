package com.example.moneyu.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.moneyu.sensores.SensoresManager

// URL del backend en tu servidor en la nube
const val MONEYU_URL = "http://TU_IP_SERVIDOR:3000"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MoneyUWebView(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            loadUrl(MONEYU_URL)
        }
    }
    DisposableEffect(Unit) {
        val sensores = SensoresManager(context) { webView.reload() }  // sacudir = recargar
        sensores.iniciar()
        onDispose { sensores.detener() }
    }
    AndroidView(factory = { webView }, modifier = modifier.fillMaxSize())
}
