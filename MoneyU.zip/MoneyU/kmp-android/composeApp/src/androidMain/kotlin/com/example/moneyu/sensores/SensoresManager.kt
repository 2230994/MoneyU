package com.example.moneyu.sensores

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/** Gestión de sensores: acelerómetro para detectar una sacudida. */
class SensoresManager(context: Context, private val alSacudir: () -> Unit) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acelerometro = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var ultimaSacudida = 0L

    fun iniciar() { acelerometro?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }
    fun detener() = manager.unregisterListener(this)

    override fun onSensorChanged(e: SensorEvent) {
        val f = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        val ahora = System.currentTimeMillis()
        if (f > 18f && ahora - ultimaSacudida > 1000) { ultimaSacudida = ahora; alSacudir() }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
