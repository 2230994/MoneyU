package com.example.moneyu.data.remote

import com.example.moneyu.data.model.EstadoApp
import com.example.moneyu.data.model.Gasto
import com.example.moneyu.data.repository.GastosRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Cliente del backend en el servidor (sin librerías extra: HttpURLConnection + org.json). */
class MoneyUApi(private val base: String) : GastosRepository {

    private suspend fun llamar(metodo: String, ruta: String, cuerpo: JSONObject? = null): String =
        withContext(Dispatchers.IO) {
            val c = URL(base.trimEnd('/') + "/api" + ruta).openConnection() as HttpURLConnection
            try {
                c.requestMethod = metodo
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (cuerpo != null) {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(cuerpo.toString().toByteArray()) }
                }
                val flujo = if (c.responseCode < 400) c.inputStream else c.errorStream
                flujo.bufferedReader().readText()
            } finally { c.disconnect() }
        }

    private fun gasto(o: JSONObject) = Gasto(
        o.getString("id"), o.getString("concepto"), o.getDouble("monto"),
        o.getString("categoria"), o.getString("fecha")
    )

    private fun estado(json: String): EstadoApp {
        val o = JSONObject(json); val a = o.getJSONArray("gastos")
        return EstadoApp(o.getDouble("presupuesto"), List(a.length()) { gasto(a.getJSONObject(it)) })
    }

    override suspend fun estado() = estado(llamar("GET", "/estado"))
    override suspend fun agregar(concepto: String, monto: Double, categoria: String) = gasto(
        JSONObject(llamar("POST", "/gastos", JSONObject().put("concepto", concepto).put("monto", monto).put("categoria", categoria)))
    )
    override suspend fun borrar(id: String) = estado(llamar("DELETE", "/gastos/$id"))
    override suspend fun llenarDemo() = estado(llamar("POST", "/demo"))
}
