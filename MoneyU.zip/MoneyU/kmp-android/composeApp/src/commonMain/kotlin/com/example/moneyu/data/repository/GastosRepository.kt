package com.example.moneyu.data.repository

import com.example.moneyu.data.model.EstadoApp
import com.example.moneyu.data.model.Gasto

/** Contrato de datos (KMP). Los datos viven en el servidor, no en el dispositivo. */
interface GastosRepository {
    suspend fun estado(): EstadoApp
    suspend fun agregar(concepto: String, monto: Double, categoria: String): Gasto
    suspend fun borrar(id: String): EstadoApp
    suspend fun llenarDemo(): EstadoApp
}
