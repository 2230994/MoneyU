package com.example.moneyu.data.model

data class Gasto(
    val id: String,
    val concepto: String,
    val monto: Double,
    val categoria: String,
    val fecha: String
)

data class EstadoApp(
    val presupuesto: Double,
    val gastos: List<Gasto>
) {
    val gastado: Double get() = gastos.sumOf { it.monto }
    val quedan: Double get() = presupuesto - gastado
}

val CATEGORIAS = listOf("Comida", "Transporte", "Diversión", "Escuela", "Otros")
