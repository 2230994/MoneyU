#!/bin/bash
cd "$(dirname "$0")/backend" && echo "Abre http://localhost:3000" && node server.js
