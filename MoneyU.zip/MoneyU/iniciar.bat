@echo off
cd /d "%~dp0backend"
echo Abre http://localhost:3000 en tu navegador
node server.js
pause
