// URL del backend.
// - Servido por el backend (http://IP:3000): déjalo vacío ('') y usa el mismo servidor.
// - Abierto con doble clic (file://): apunta al backend local.
// - Frontend en otro servidor: pon aquí la URL del backend, ej. 'http://TU_IP_SERVIDOR:3000'
window.MONEYU_API = location.protocol === 'file:' ? 'http://localhost:3000' : '';
