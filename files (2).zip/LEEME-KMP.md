# Integrar MoneyU en tu proyecto KMP

## Carpetas que se crean en Android Studio (composeApp/src)
```
commonMain/kotlin/<package>/data/model/Gasto.kt            modelos (Gasto, EstadoApp)
commonMain/kotlin/<package>/data/repository/GastosRepository.kt   contrato de datos
androidMain/kotlin/<package>/data/remote/MoneyUApi.kt      cliente del servidor (datos en la nube)
androidMain/kotlin/<package>/sensores/SensoresManager.kt   gestión de sensores (acelerómetro)
androidMain/kotlin/<package>/ui/MoneyUWebView.kt           pantalla que muestra MoneyU
```

## Opción rápida (Git Bash)
```bash
cd MoneyU/kmp-android
./instalar.sh "/c/Users/TU_USUARIO/AndroidStudioProjects/TuProyecto" com.tuapp.paquete http://IP_SERVIDOR:3000
```
Si no usas el script, copia las carpetas a mano y cambia `package` y `MONEYU_URL`.

## Faltan 2 cosas manuales
1. `composeApp/src/androidMain/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<application ... android:usesCleartextTraffic="true">   <!-- por usar http:// -->
```
2. En tu `MainActivity` (androidMain): `setContent { MoneyUWebView() }`
   (importa `<package>.ui.MoneyUWebView`).

Luego: Sync Gradle, instala en el celular, sacude el teléfono para recargar.
No se agregan dependencias nuevas (no hay que tocar Gradle).
Archivos de sensores para la rúbrica: sensores/SensoresManager.kt y AndroidManifest.xml
