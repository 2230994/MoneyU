#!/bin/bash
# Uso (Git Bash):  ./instalar.sh "/c/Users/TU_USUARIO/AndroidStudioProjects/TuProyecto" com.tuapp.paquete http://IP:3000
# Crea las carpetas data/model, data/repository, data/remote, sensores y ui dentro de tu proyecto KMP.
set -e
PROY="$1"; PKG="${2:-com.example.moneyu}"; URL="${3:-http://TU_IP_SERVIDOR:3000}"
[ -d "$PROY/composeApp/src" ] || { echo "No encuentro $PROY/composeApp/src (revisa la ruta o el nombre del módulo)"; exit 1; }
RUTA=$(echo "$PKG" | tr . /)
AQUI="$(cd "$(dirname "$0")" && pwd)/composeApp/src"
for f in $(cd "$AQUI" && find . -name '*.kt'); do
  destino="$PROY/composeApp/src/$(echo "$f" | sed "s#com/example/moneyu#$RUTA#")"
  mkdir -p "$(dirname "$destino")"
  sed -e "s/com\.example\.moneyu/$PKG/g" -e "s#http://TU_IP_SERVIDOR:3000#$URL#" "$AQUI/$f" > "$destino"
  echo "creado: $destino"
done
echo "Listo. Falta: permisos en AndroidManifest.xml y setContent { MoneyUWebView() } (ver LEEME-KMP.md)"
